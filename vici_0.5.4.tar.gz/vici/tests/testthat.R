library(testthat)
library(vici)

test_check("vici")

# vici 0.5.3

 * Added source code & CRAN link buttons

# vici 0.5.1

 * First completely operational version of the app

# vici 0.1.0

 * Modularizing code

# vici 0.0.5.0

 * Debugging multiple responses

# vici 0.0.3.0

 * Using tab and allowing more than 2 levels in factors

# vici 0.0.2.0

 * First beta working for inter-arm comparison (2-arms)

# vici 0.0.0.9000

 * Added a `NEWS.md` file to track changes to the package.
